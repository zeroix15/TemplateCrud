<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Alif-soloproject</title>
	<meta name="title" content="Alif-soloproject">

    
    

	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">

	<link rel="stylesheet" href="<?php echo base_url();?>assets///maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index-stylesheet.css">
</head>

<body class="" id="">

    <!-- Menu -->
    <nav class="menu" id="theMenu">
        <div class="menu-wrap">
            <h1 class="logo"><a href="index.html#home">Universe</a></h1>
            <i class="fa fa-remove menu-close"></i>
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-dribbble"></i></a>
            <a href="#"><i class="fa fa-envelope"></i></a>
        </div>

        <!-- Menu button -->
        <div id="menuToggle"><i class="fa fa-reorder"></i>
        </div>
    </nav>



    <!-- ========== HEADER SECTION ========== -->
    <section id="home" name="home"></section>
    <div id="headerwrap">
        <div class="container">
            <div class="logo">
                <img src="<?php echo base_url();?>assets/images/logo.png">
            </div>
            <br>
            <div class="row">
                <h1>CRUD</h1>
                <br>
                <h3>Create, Read, Update. Delete</h3>
                <br>
                <br>
                <div class="col-lg-6 col-lg-offset-3">
                </div>
            </div>
        </div>
        <!-- /container -->
    </div>
    <!-- /headerwrap -->



    <!-- ========== ABOUT SECTION ========== -->
    <section id="about" name="about"></section>
    <div id="f">
        <div class="container">
            <div class="row">
                <h3>ABOUT</h3>
                <p class="centered"><i class="fa fa-circle"></i><i class="fa fa-circle"></i><i class="fa fa-circle"></i><br><br>				A Crud Sample in Codeigniter
                </p>
				
                <!-- INTRO INFORMATIO-->
                <div class="col-lg-6 col-lg-offset-3">
          
                </div>
            </div>
        </div>
        <!-- /container -->
    </div>
    <!-- /f -->


    <!-- ========== CAROUSEL SECTION ========== -->
    <section id="portfolio" name="portfolio"></section>
  
			
			<div class="container">
	<h1 class="page-header text-center">CodeIgniter Simple CRUD Tutorial</h1>
	<div class="row">
		<div class="col-sm-4 col-sm-offset-4">
			<h3>Add Form
				<span class="pull-right"><a href="<?php echo base_url(); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-arrow-left"></span> Back</a></span>
			</h3>
			<hr>
			<form method="POST" action="<?php echo base_url(); ?>index.php/users/insert">
				<div class="form-group">
					<label>Username:</label>
					<input type="text" class="form-control" name="username">
				</div>
				<div class="form-group">
					<label>Password:</label>
					<input type="text" class="form-control" name="password">
				</div>
				<div class="form-group">
					<label>FullName:</label>
					<input type="text" class="form-control" name="fname">
				</div>
				<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</button>
			</form>
		</div>
	</div>
</div>
					</div>
	</div>
</div>
    <!-- f -->

    <!-- ========== CONTACT SECTION ========== -->
    <section id="contact" name="contact"></section>
    <div id="f">
        <div class="container">
            <div class="row">
                <h3>CONTACT ME</h3>
                <p class="centered"><i class="fa fa-circle"></i><i class="fa fa-circle"></i><i class="fa fa-circle"></i>
                </p>

                <div class="col-lg-6 col-lg-offset-3">
                    <p id="">Some Avenue, 987
                        <br>Madrid, Spain
                        <br>+34 8984-4343</p>
                    <p>mail@me.com</p>
                    <p>
                        <button type="button" class="btn btn-warning">CONTACT ME</button>
                    </p>
                </div>
            </div>
        </div>
    </div>
<script src="<?php echo base_url();?>assets/js/jquery.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.js"></script>
<script src="<?php echo base_url();?>assets/js/classy.js"></script>
<script src="<?php echo base_url();?>assets/js/chart.js"></script>
<script id="main-script" src="<?php echo base_url();?>assets/js/index-scripts.js"></script>
</body>

</html>